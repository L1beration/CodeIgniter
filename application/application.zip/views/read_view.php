<h1>Список студентов</h1>
<div id="body">
    <table>
        <?php
            foreach ($data as $valueArray) {
                $i = 0;
                echo '<tr><td>';
                foreach ($valueArray as  $value) {
                    if($i == 0)
                        echo '<a href = "/index.php/student_controller/find/'.$value.'/">';
                    echo htmlspecialchars($value).'</td><td>';
                    $i++;
                }
                echo '</td></tr>';
                
            }
         ?>
    </table>
<div/>