<h1>Изменить запись</h1>
<div id="body">
    <form action =<?echo '/index.php/student_controller/update/'.$id.'/';?> method ='post'>
        <p>
            <label>Введите новое имя<label/>
            <input name ='student_new_name'>
            <input name ='student_old_name' type ="hidden" value =<? echo $data ?>>
        <p/>
        <label>Выберите группу<label/>
        <select name="class_id" size="1">
            <option value='1'>Группа 1</option>
            <option value='2'>Группа 2</option>
        </select>
        <p><input name="submit" type="submit" id="submit" value="Изменить" />
    </form>
    <? echo validation_errors(); ?>
<div/>