<h1>Войти</h1>
<div id="body">
    <form action =<? echo site_url($this->uri->uri_string);?> method ='post'>
        <p>
            <label>Введите имя<label/>
            <input name ='login'>
        <p/>
        <p>
            <label>Введите пароль<label/>
            <input name ='password' type ="password">
        <p/>
        <p><input name="submit" type="submit" id="submit" value="Войти" />
    </form>
        <? echo $data;?>  
        <? echo validation_errors(); ?>
<div/>