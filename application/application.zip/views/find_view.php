<script>
function confirmDelete() {
	if (confirm("Вы подтверждаете удаление?")) {
		return true;
	} else {
		return false;
	}
}
</script>

<h1>Список студентов</h1>
<div id="body">
    <?
        echo   htmlspecialchars($data[0]['student_name']).' '.$data[0]['class_name'];
    
        echo '<a href="/index.php/student_controller/update/'.$data[0]['id'].'/" class = "design">Изменить</a>';
        echo '<a href="/index.php/student_controller/delete/'.$data[0]['id'].'/" onclick="return confirmDelete();" class = "design">Удалить</a>';      
    ?>
    
<div/>