<?php
class Student_Model extends CI_Model
{
    function get_student()
    {
        $this->db->select('students.id, student_name, class_name');
        $this->db->from('students');
        $this->db->join('classes', 'students.class_id = classes.id');

        $this->load->helper('security');
        
        return $this->db->get()->result_array();
    }
    
    function find_student($id)
    {
        $this->db->select('student_name, class_name, students.id');
        $this->db->from('students');
        $this->db->join('classes', 'students.class_id = classes.id');
        $this->db->where('students.id', $id);
        
        $this->load->helper('security');

        return $this->db->get()->result_array();
    }

    function create_student()
    {
        if(isset($_POST['student_name']) && isset($_POST['class_id'])){
            $data = array(
                'student_name' => $_POST['student_name'] ,
                'class_id' => $_POST['class_id'] ,
            );

            $this->db->insert('students', $data);
            $this->load->helper('url');
            redirect(site_url());
         }
    }

    function update_student($id)
    {
        if(isset($_POST['student_new_name']) && isset($_POST['class_id'])){
            $data = array(
               'student_name' => $_POST['student_new_name'],
               'class_id' => $_POST['class_id'],
            );

            $this->db->where('id', $id);
            $this->db->update('students', $this->db->escape($data)); 
            $this->load->helper('url');
            redirect(site_url());
        }
    }

    function delete_student($id)
    {
        if(isset($id)){
            $this->db->where('id', $id);
            $this->db->delete('students'); 
       }
    }
}