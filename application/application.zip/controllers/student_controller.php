<?php
class Student_Controller extends CI_Controller
{
    function index()
    {
        $this->load->model('Student_Model', '', true);
        $data['data'] = $this->Student_Model->get_student();
        $data['content_view'] = 'read_view';
        $this->load->view('template', $data);
    }
    
    function find($id)
    {
        $this->load->library('session');
        $check_auth = $this->session->userdata('logged_in');
        if ($check_auth) 
        {  
            $this->load->model('Student_Model', '', true);
            $data['data'] = $this->Student_Model->find_student($id);
            $data['content_view'] = 'find_view';
            $this->load->view('template', $data);
        }
        else 
        {
            $this->load->library('auth_controller');
            $this->auth_controller->auth('find');
        }
    }
    
    function create()
    {
        $this->load->library('session');
        $check_auth = $this->session->userdata('logged_in');
        if ($check_auth) 
        {  
            $this->load->model('Student_Model', '', true);
            $this->load->helper(array('form', 'url'));
            $this->load->library('form_validation');

            $config = array(
                   array(
                         'field'   => 'student_name',
                         'label'   => 'Имя студента',
                         'rules'   => 'trim|required'
                      ),
                );
            
            $this->form_validation->set_message('required', 'Введите имя студента');
            $this->form_validation->set_rules($config); 

            if ($this->form_validation->run() == FALSE)
            {
                $data['data'] = '';
                $data['content_view'] = 'create_view';
                $this->load->view('template', $data);
            }
            else
            {
                $this->Student_Model->create_student();
            }
        }
        else {
            $this->load->library('auth_controller');
            $this->auth_controller->auth('create');
        }
    }
    
    function update($id)
    {
        $student_old_name = '';
        $this->load->model('Student_Model', '', true);     
        $this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
        
        $config = array(
               array(
                     'field'   => 'student_new_name',
                     'label'   => 'Имя студента',
                     'rules'   => 'trim|required'
                  ),
            );
        
        $this->form_validation->set_message('required', 'Введите имя студента');
        $this->form_validation->set_rules($config); 
        
        
        if ($this->form_validation->run() == FALSE)
        {
            $data['data'] = array(
                'data' => $_POST[$student_old_name],
                'id' => $id
                    );
            $data['content_view'] = 'update_view';
            $this->load->view('template', $data);
        }
        else
            $this->Student_Model->update_student($id, $student_name);
        
    }
    
    function delete($id)
    {
        $this->load->model('Student_Model', '', true);
        $this->Student_Model->delete_student($id);
        $this->load->helper('url');
        redirect(site_url());
    }
}
